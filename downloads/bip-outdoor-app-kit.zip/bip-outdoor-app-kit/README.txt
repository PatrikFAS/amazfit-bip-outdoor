Bip Outdoor app kit

For the original Amazfit Bip (A1608) already running BipOS 0.5.5 build 7
on English non-Latin firmware 1.1.2.05.

Open a terminal in this folder. Run 'python3 assemble-res.py' on macOS or
Linux, or 'py -3 assemble-res.py' on Windows. Python downloads the matching
upstream files and creates bip-outdoor-suite.res. Open that RES file on
your paired Android phone with Gadgetbridge's FW/App Installer.

Record any waypoints you want to keep before updating the resources.
The kit includes sun and twilight calculations for Point Atkinson, BC.
See the project page for build instructions to include tide predictions.

https://github.com/PatrikFAS/amazfit-bip-outdoor
